﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Demo_Dimension.Data.Migrations
{
    public partial class InitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "DimensionModel",
                columns: table => new
                {
                    Age = table.Column<string>(nullable: false),
                    Attrition = table.Column<string>(nullable: true),
                    BusinessTravel = table.Column<string>(nullable: true),
                    DailyRate = table.Column<string>(nullable: true),
                    Education = table.Column<string>(nullable: true),
                    EducationField = table.Column<string>(nullable: true),
                    Department = table.Column<string>(nullable: true),
                    DistanceFromHome = table.Column<string>(nullable: true),
                    EmployeeCount = table.Column<string>(nullable: true),
                    EmployeeNumber = table.Column<string>(nullable: true),
                    EnvironmentSatisfaction = table.Column<string>(nullable: true),
                    Gender = table.Column<string>(nullable: true),
                    HourlyRate = table.Column<string>(nullable: true),
                    JobInvolvement = table.Column<string>(nullable: true),
                    JobLevel = table.Column<string>(nullable: true),
                    JobRole = table.Column<string>(nullable: true),
                    JobSatisfaction = table.Column<string>(nullable: true),
                    MaritalStatus = table.Column<string>(nullable: true),
                    MonthlyIncome = table.Column<string>(nullable: true),
                    MonthlyRate = table.Column<string>(nullable: true),
                    NumCompaniesWorked = table.Column<string>(nullable: true),
                    Over18 = table.Column<string>(nullable: true),
                    OverTime = table.Column<string>(nullable: true),
                    PercentSalaryHike = table.Column<string>(nullable: true),
                    PerformanceRating = table.Column<string>(nullable: true),
                    RelationshipSatisfaction = table.Column<string>(nullable: true),
                    StandardHours = table.Column<string>(nullable: true),
                    StockOptionLevel = table.Column<string>(nullable: true),
                    TotalWorkingYears = table.Column<string>(nullable: true),
                    TrainingTimesLastYear = table.Column<string>(nullable: true),
                    WorkLifeBalance = table.Column<string>(nullable: true),
                    YearsAtCompany = table.Column<string>(nullable: true),
                    YearsInCurrentRole = table.Column<string>(nullable: true),
                    YearsSinceLastPromotion = table.Column<string>(nullable: true),
                    YearsWithCurrManager = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DimensionModel", x => x.Age);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DimensionModel");
        }
    }
}
